fun printUserGroup(group: String, vararg users: String, count: Int){
	println("Group: $group")
	println("Count: $count")
	for(user in users)
		println(user)
}
fun main(args: Array<String>){
	printUserGroup("KT-001","Tom","Bob", "Alice", count=3)
}